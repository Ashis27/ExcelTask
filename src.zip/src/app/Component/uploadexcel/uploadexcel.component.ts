import { Component, OnInit } from '@angular/core';
import { UploadExcelServiceProvider } from 'src/providers/uploadexcel.service/uploadexcel.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-uploadexcel',
  templateUrl: './uploadexcel.component.html',
  styleUrls: ['./uploadexcel.component.scss']
})
export class UploadexcelComponent implements OnInit {
  uploadedExcelFile: any = {};
  isUploaded: boolean = false;
  constructor(private toastr: ToastrService, private _uploadExcelService: UploadExcelServiceProvider) { }

  ngOnInit() {

  }
  onFileChangeFile(event) {
    this.uploadedExcelFile = <File>event.target.files[0]
  }

  uploadExcelFile() {
    if (this.uploadedExcelFile && this.uploadedExcelFile.name) {
      this._uploadExcelService.UploadExcelFile(this.uploadedExcelFile)
        .subscribe(response => {
         this.isUploaded = true;
          this.toastr.success("Successfully uploaded");
        },
          error => {
            this.toastr.error(error);
          });
    }
    else {
      this.toastr.error("Please select a file");
    }
  }
  downloadFile() {
    this._uploadExcelService.DownloadFile(this.uploadedExcelFile.name)
      .subscribe(response => {
        
      },
        error => {
          this.toastr.error(error);
        });
  }
}
