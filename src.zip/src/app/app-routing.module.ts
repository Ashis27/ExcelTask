import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UploadexcelComponent } from 'src/app/Component/uploadexcel/uploadexcel.component';

const routes: Routes = [
  {
    path: '', component: UploadexcelComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
