import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UploadexcelComponent } from './Component/uploadexcel/uploadexcel.component';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { HeaderInterceptor } from '../providers/header.interceptor';
import { ErrorInterceptor } from 'src/providers/error.interceptor';
import { UploadExcelServiceProvider } from 'src/providers/uploadexcel.service/uploadexcel.service';
import { HttpServiceProvider } from 'src/providers/http.services';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';


@NgModule({
  declarations: [
    AppComponent,
    UploadexcelComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({
        timeOut: 2000,
        positionClass: 'toast-top-right',
        preventDuplicates: true,
    }),
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: HeaderInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    UploadExcelServiceProvider,
    HttpServiceProvider
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
