import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpServiceProvider } from '../http.services';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';


@Injectable()
export class UploadExcelServiceProvider {
  private _get_API_URL = "http://localhost:34728/api/UploadExcel/";
  constructor(public _httpService: HttpServiceProvider) {

  }

  UploadExcelFile = (fileInfo): Observable<any> => {
    const formData: any = new FormData()
    formData.append("fileInfo", fileInfo, fileInfo['name']);
    return this._httpService.post(this._get_API_URL + "UpdateExcelSheet", formData)
      .pipe(tap(response => {
        return response;
      }));
  }
DownloadFile = (fileName): any => {
      window.open(this._get_API_URL + "DownloadUpdatedFile?fileName=" + fileName)
  }
}
