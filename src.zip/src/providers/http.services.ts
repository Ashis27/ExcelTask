import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
import { Observable } from 'rxjs';

/*
 * Generated class for the http.service provider.
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
*/
@Injectable()
export class HttpServiceProvider {

    /**
     *@ignore
     */
    constructor(private _http: HttpClient) { }

    /**
     * HTTP get service
     * @param {string} url api url to get data
     * @param {boolean} status True | false (Use loader or not)
     * @returns HTTP response
     */
    get(url: string, status?: any): Observable<any> {
        return this._http.get<any>(url);
    }

    
    /**
     * HTTP post service
     * @param {string} url api url to get data
     * @param {object} model data to be stored in DB
     * @param {boolean} status True | false (Use loader or not)
     * @returns HTTP response
     */
    post(url: string, model: any, status?: any): Observable<any> {

        return this._http.post<any>(url, model);
    }

     /**
     * HTTP put service
     * @param {string} url api url to get data
     * @param {object} model data to be stored in DB
     * @returns HTTP response
     */
    put(url: string, model: any): Observable<any> {
        return this._http.put<any>(url, model);
    }

     /**
     * HTTP delete service
     * @param {string} url api url to get data
     * @returns HTTP response
     */
    delete(url: string): Observable<Response> {
        return this._http.delete<any>(url);
    }
}
