import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

/**
 * Error interceptor
 */
@Injectable()
export class ErrorInterceptor implements HttpInterceptor {

    /**
     * @ignore
     */
    constructor() { }

    /**
     *Throw error while throwing any error from API
     *@example
     *intercept()
     *@returns {void}
     */
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<any> {
        if (navigator.onLine)
            return next.handle(request).pipe(catchError(err => {
                if (err.status === 400)
                    return throwError(err.error.message);
                return throwError("Something went wrong. Please try again");
            }));
        else
            return Observable.throw("You are offline. Please check your network connection");
    }
}